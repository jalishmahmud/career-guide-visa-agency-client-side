import * as React from "react";
import "./App.css";
import Home from "./Pages/Home/Home/Home";
function App() {
  return (
    <div>
      <Home></Home>
    </div>
  );
}

export default App;
